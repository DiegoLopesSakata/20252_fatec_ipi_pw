package com.fatec.PetStop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetStopApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetStopApplication.class, args);
	}

}
