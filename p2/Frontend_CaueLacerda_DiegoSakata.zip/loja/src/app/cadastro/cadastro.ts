import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';
@Component({
  selector: 'app-cadastro',
  imports: [CommonModule, FormsModule],
  templateUrl: './cadastro.html',
  styleUrl: './cadastro.css',
})
export class Cadastro {
  mensagem: string = "";
  obj:Cliente=new Cliente();

  gravar(){
    this.obj.ativo = 1;
    localStorage.setItem("cliente", JSON.stringify(this.obj));
    this.mensagem = "Cadastro realizado com sucesso!";

    this.obj = new Cliente();
  }
}
