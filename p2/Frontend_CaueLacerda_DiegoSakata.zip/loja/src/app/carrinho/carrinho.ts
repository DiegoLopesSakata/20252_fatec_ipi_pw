import { Component, OnInit } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { Cart } from '../cart';
import { Product } from '../model/cliente';
import { Router } from '@angular/router';

@Component({
  selector: 'app-carrinho',
  imports: [CommonModule, DecimalPipe],
  templateUrl: './carrinho.html',
  styleUrl: './carrinho.css',
})
export class Carrinho implements OnInit {
   cart: Product[] = [];

  constructor(private Cart: Cart, private router: Router) { }

  ngOnInit(): void {
    this.cart = this.Cart.getCart();
  }

  goToVitrine(){
    this.router.navigate(['/vitrine']);
  }

  getTotal(): number {
    return this.cart.reduce((total, item) => total + item.price, 0);
  }

  removeFromCart(item: any) {
    this.cart = this.cart.filter(cartItem => cartItem.id !== item.id);
    localStorage.setItem('cart', JSON.stringify(this.cart));  
  }
}
