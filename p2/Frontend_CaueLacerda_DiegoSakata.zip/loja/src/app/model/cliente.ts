export class Cliente {
    codigo: number = 0;
    nome: string = "";
    email: string = "";
    senha: string = "";
    documento: string = "";
    telefone: string = "";
    logradouro: string = "";
    cidade: string = "";
    cep: string = "";
    complemento: string = "";
    ativo: number = 0;
}

export interface Product {
  id: number;
  name: string;
  category: string;
  description: string;
  price: number;
  image: string;
}
