import { Component, OnInit } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { Cart } from '../cart';
import { Product } from '../model/cliente';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vitrine',
  imports: [CommonModule, DecimalPipe],
  templateUrl: './vitrine.html',
  styleUrl: './vitrine.css',
})
export class Vitrine implements OnInit {

  constructor(
    private Cart: Cart,
    private router: Router          
  ) {}

  ngOnInit(): void {}

  addToCart(product: Product) {
    this.Cart.addToCart(product);

    this.router.navigate(['/carrinho']);
  }


  
  products = [
    { id: 1, name: 'Ração Premium Gatos', category: 'Alimentação', description: 'Ração super premium para gatos adultos de todas as raças', price: 89.90, image: 'racao_gato.jpg' },
    { id: 2, name: 'Brinquedo para Gatos', category: 'Brinquedos', description: 'Kit completo com arranhador e brinquedos interativos', price: 24.90, image: 'brinquedo_gato.jpg' },
    { id: 3, name: 'Coleira e Guia Premium', category: 'Acessórios', description: 'Conjunto resistente e confortável para passeios', price: 45.90, image: 'cachorro.webp'}
  ];

}
