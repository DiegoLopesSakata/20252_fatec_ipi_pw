import { Routes } from '@angular/router';
import { Vitrine } from './vitrine/vitrine';
import { Sobre } from './sobre/sobre';
import { Contato } from './contato/contato';
import { Cadastro } from './cadastro/cadastro';
import { Carrinho } from './carrinho/carrinho';
export const routes: Routes = [
    {path:"vitrine", component:Vitrine},
    {path:"sobre", component:Sobre},
    {path:"contato", component:Contato},
    {path:"", component:Vitrine},
    {path:"cadastro", component:Cadastro},
    {path: "carrinho", component:Carrinho}
];
