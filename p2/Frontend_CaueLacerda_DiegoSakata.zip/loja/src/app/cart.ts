import { Injectable, Inject } from '@angular/core';
import { PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Product } from './model/cliente';

@Injectable({
  providedIn: 'root',
})
export class Cart {
    private cart: Product[] = [];
  private isBrowser: boolean;

  constructor(@Inject(PLATFORM_ID) platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);

    if (this.isBrowser) {
      const saved = localStorage.getItem('cart');
      if (saved) {
        this.cart = JSON.parse(saved);
      }
    }
  }

  addToCart(product: Product) {
    this.cart.push(product);
    if (this.isBrowser) {
      localStorage.setItem('cart', JSON.stringify(this.cart));
    }
  }

  getCart(): Product[] {
    return this.cart;
  }

  removeItem(product: Product) {
    this.cart = this.cart.filter(item => item.id !== product.id);
    if (this.isBrowser) {
      localStorage.setItem('cart', JSON.stringify(this.cart));
    }
  }

  clearCart() {
    this.cart = [];
    if (this.isBrowser) {
      localStorage.removeItem('cart');
    }
  }
}
